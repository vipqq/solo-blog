title: Windows10关闭自动更新
date: '2019-11-18 22:07:23'
updated: '2019-11-18 22:15:43'
tags: [Windows]
permalink: /articles/2019/11/18/1574086043362.html
---
##### 如下步骤
1.找到windows图标右击选择 col1Windows PowerShell(管理员)
2.输入
```html
REG add "HKLM\SYSTEM\CurrentControlSet\Services\WaaSMedicSvc" /v "Start" /t REG_DWORD /d "4" 
```
