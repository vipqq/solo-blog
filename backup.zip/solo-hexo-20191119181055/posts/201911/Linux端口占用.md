title: Linux端口占用
date: '2019-11-18 21:50:47'
updated: '2019-11-18 21:55:25'
tags: [Linux]
permalink: /articles/2019/11/18/1574085047344.html
---
## 方式一：lsof命令

1、查看占用端口进程的PID：

```html
lsof -i:{端口号}
```
2、根据PID kill掉相关进程：

```html
kill -9 {PID}
```
## 方式二：netstat命令
1、查看占用端口进程的PID：

```perl
netstat -tunlp|grep {port}
```
2、kill方法如上

```html
kill -9 {PID}
```
## 方式三： 根据程序名查看对应的PID
1、用ps命令（装逼专用）：

```html
ps -ef | grep {programName}
```
```html
kill -9 {PID}
```
2、用pgrep命令：

pgrep命令的p表明了这个命令是专门用于进程查询的grep。

```html
pgrep {programName}
```
```html
kill -9 {PID}
```
